# ----------------------------------
# 03 - Ejercicio de Recursividad
# Convertir de Base 10 a Binario
# ----------------------------------

# Ejercicio 1.
# Convertir un numero en base 10 a base 2

# 13 / 2 = 6 Residuo 1                  
#  6 / 2 = 3 Residuo 0
#  3 / 2 = 1 Residuo 1
#  1 / 2 = 0 Residuo 1
#            8421
# Binario -> 1101


# Convertir un Numero de Base 10 a Binario Usando Recursividad
def fnNumeroBase10ABase2(numeroBase10):
    """Función Recursiva para Convertir un Numero Base 10 a Base 2"""
  
    # Variable de Resultado
    resultado = ""

    # Validamos el Numero
    if (numeroBase10>=0):

        # Verificamos que es 0
        if (numeroBase10 >0):    
            # Obtiene el Residuo
            residuo = str(numeroBase10 % 2)

            # Calcula el resultado llamando a función recursiva
            resultado = fnNumeroBase10ABase2(int(numeroBase10/2)) + residuo
                        
            # Despliega el resultado
            print("El Binario de ", numeroBase10, "es:",resultado)                
    else:
        print("Error en Numero en Base 10")        
    
    # Retorna
    return resultado

# Probamos
base2 = fnNumeroBase10ABase2(13)

