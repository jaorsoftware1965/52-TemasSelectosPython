# ---------------------------------------
# 16 - Ejercicios de Recursividad
# ---------------------------------------

# Sumar Recursivamente

# 0 1 1 1 0      <- Acarreo

# 1 3 4 5 6
#   2 3 4 5
# 1 2 3 4 5
#     3 0 0
# ---------
# 2 8 4 4 6

# a) Recibiremos la lista de Números, nivel y acarrero
# b) Obtendremos los de la derecha de la cadena y los sumaremos;
# c) El Nivel indica si tenemos que multiplicar por 1,10,100, etc.
# d) Obtendremos que es lo que exceda de 10 en la suma
# e) A cada cadena le quitaremos el caracter derecho
# f) Llamaremos de nuevo a la función recursiva


# Sumar Recursivamente
def fnSumarRecursivamente(listaNumeros, nivel=0,acarreo=0):
    """Función Recursiva para sumar"""
  
    # Variable de Resultado
    resultado = 0

    # Variable para sumar los caracteres de la Derecha
    # la iniciamos con el acarreo
    suma = acarreo

    # Ciclo para obtener cada numero en la lista
    for numero in listaNumeros:
        # obtenemos el digito derecho convertido a int
        digitoDerecho = int(numero[len(numero)-1])

        # lo sumamos
        suma = suma + digitoDerecho
        
    # dividimos entre 10 para obtener el acarreo
    acarreoNvo = int((suma/10))

    # La suma solo son las unidades que son el residuo
    suma = suma % 10

    # Multiplicamos por el nivel
    suma = suma * (10**nivel)

    # Creamos una nueva lista solo con aquellos numeros 
    # que todavía tienen digitos
    nvaLista=[]

    # Ciclo para eliminar el digito derecho en cada lista
    # que tenga por lo menos 2 digitos
    for numero in listaNumeros:
        if (len(numero)>1):
            # le quita el derecho
            numeroNuevo = numero[0:len(numero)-1]
            
            # Lo agrega a la lista
            nvaLista.append(numeroNuevo)
    
    # Verificamos si todavía hay numeros que sumar
    if (len(nvaLista)>0):
       # Cuando termine el ciclo, llamamos recursivamente
       resultado = suma + fnSumarRecursivamente(nvaLista,nivel+1,acarreoNvo)
    else:
       # Acá finaliza
       resultado = suma    

    # Desplegamos
    print("La Suma de:",listaNumeros,"acarreo",acarreo,"es:",resultado)

                
    # Retorna
    return resultado

# Probamos
listaNumerosSumar=["13456","2345","12345","300"]

# Llamamos a la función
fnSumarRecursivamente(listaNumerosSumar)