# ---------------------------------------
# 17 - Ejercicios de Recursividad
# ---------------------------------------

# Sumar Binaria Multiple Recursiva

# Este es el ejemplo que todo mundo conoce con 2 numeros
#                  <-Acarreos
#    1 0 1 0 1 = 21
#    1 1 0 1 1 = 27
#  ----------------
#              = 48


# Y creo que no hay algoritmos recursivos en la red que 
# lo resuelva; pero con lo que ya hemos resuelto; este
# planteamiento ya está "papitas". Vamos por algo 
# mas complicado que casi nadie, porque no ser muy
# aventurado, a resuelto manualmente

# Primer Ejemplo explicativo

#    10
#      1
#      1
#      1
#      1
#      1
#    --- 
#    101


# Acarreos
#
# 1 1
#     1
#     1 1
#         1
#         1 1
#             1
#             1 0                

#     1 0 1 0 1 1 1 =  87     
#     1 0 1 0 1 0 1 =  85
#     1 0 1 0 1 0 1 =  85
#     1 0 1 0 0 1 1 =  83
#     1 1 1 1 1 1 1 = 127
# -----------------
# 1 1 1 0 1 0 0 1 1 = 467


# 12  <- Acarreo
# 256
# 128
#  64
#  16
#   2
#   1
# ---
# 467


# Importamos el archivo con la función para convertir a Binario
import Base10aBase2Recursivo as p

# Función para sumar n Numeros Binarios Recursivamente
def fnSumarBinariosRecursivamente(listaNumerosBinarios):
    """Función para sumar números binarios recursivamente"""

    # Variable de Resultado
    resultado = ""

    # Variable para sumar
    suma = 0

    # Ciclo para obtener los digitos derechos de la expresión
    for numero in listaNumerosBinarios:
        # obtenemos el digito derecho convertido a int
        digitoDerecho = int(numero[len(numero)-1])

        # lo sumamos
        suma = suma + digitoDerecho

    # Convertimos a binario el Numero
    sumaEnBinario = p.fnNumeroBase10ABase2(suma)    

    # El Resultado es el numero derecho de la suma
    resultado = sumaEnBinario[len(sumaEnBinario)-1]

    # Declaramos la nvaListaNumeros
    nvaLista = []

    # Verificamos si la longitud de la sumaEnBinario tiene mas de un digito
    if (len(sumaEnBinario)>1):
        # Eliminamos la parte derecha de la suma
        nvoNumero = sumaEnBinario[0:len(sumaEnBinario)-1]
        # Se agrega a la nueva lista
        nvaLista.append(nvoNumero)

    # Ciclo para eliminar el digito derecho en cada numero
    # y agregar solo los que tengan por lo menos 2 digitos
    for numero in listaNumerosBinarios:
        if (len(numero)>1):
            # le quita el derecho
            numeroNuevo = numero[0:len(numero)-1]
            
            # Lo agrega a la lista
            nvaLista.append(numeroNuevo)
    
    # Verificamos si todavía hay numeros que sumar
    if (len(nvaLista)>0):
       # Cuando termine el ciclo, llamamos recursivamente
       resultado = fnSumarBinariosRecursivamente(nvaLista)+resultado

    # Desplegamos
    print("La Suma de:",listaNumerosBinarios,"es:",resultado)

                
    # Retorna
    return resultado


# Probamos
lista = ["1010111","1010101","1010101","1010011","1111111"]

# Llama a la Función
fnSumarBinariosRecursivamente(lista)