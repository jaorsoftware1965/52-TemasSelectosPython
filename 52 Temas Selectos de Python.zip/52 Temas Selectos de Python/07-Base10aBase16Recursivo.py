# ----------------------------------
# 07 - Ejercicio de Recursividad
# Convertir de Base 10 a Hexadecimal
# ----------------------------------

# Ejercicio 5.
# Convertir un numero en base 10 a base 16

# 68 / 16 = 4 Residuo 4
#  4 / 16 = 0 Residuo 4
# Hexadecimal -> 44

# 135 / 16 = 8 Residuo 7
#   8 / 16 = 0 Residuo 8
# Hexadecimal -> 87


# Función para obtener el digito Hexadecimal de 10 hasta 15
def fnObtenerDigitoHexadecimal(valor):
    # Resultado
    resultado = ""

    if (valor   == 10):
       resultado = "a"
    elif (valor == 11):
       resultado = "b" 
    elif (valor == 12):
       resultado = "c" 
    elif (valor == 13):
       resultado = "d" 
    elif (valor == 14):
       resultado = "e"          
    elif (valor == 15):
       resultado = "f" 

    # Devuelve el resultado
    return resultado       



# Convertir un Numero de Base 10 a Hexadecimal Usando Recursividad
def fnNumeroBase10ABase16(numeroBase10):
    """Función Recursiva para Convertir un Numero Base 10 a Base 16"""
  
    # Variable de Resultado
    resultado = ""

    # Validamos el Numero
    if (numeroBase10>=0):

        # Verificamos que es mayor que 0
        if (numeroBase10 >0):    
            # Obtiene el Residuo
            residuo = numeroBase10 % 16

            # Verificamos si es menor quw 10
            if (residuo < 10):
                # Lo convertimos a cadena
                residuo = str(residuo)
            else:
                # obtenemos el digito
                residuo = fnObtenerDigitoHexadecimal(residuo)

            # Calcula el resultado llamando a función recursiva
            resultado = fnNumeroBase10ABase16(int(numeroBase10/16)) + residuo
                        
            # Despliega el resultado
            print("El Hexadecimal de ", numeroBase10, "es:",resultado)                
    else:
        print("Error en Numero en Base 10")        

    
    
    # Retorna
    return resultado

# Probamos
base16 = fnNumeroBase10ABase16(68)
print()

base16 = fnNumeroBase10ABase16(135)
print()

base16 = fnNumeroBase10ABase16(255)
print()

base16 = fnNumeroBase10ABase16(256)
print()

