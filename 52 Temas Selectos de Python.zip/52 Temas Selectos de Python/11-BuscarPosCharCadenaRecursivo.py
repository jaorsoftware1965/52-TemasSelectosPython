# ---------------------------------------
# 11 - Ejercicios de Recursividad
# ---------------------------------------


# Buscar un Caracter en una cadena


# Verifica si es palíndrome
def fnBuscarPosCaracter(cadena, caracter, pos=0):
    """Función Recursiva para buscar un Caracter en una Cadena"""
  
    # Variable de Resultado
    resultado = -1

    # Validamos el Numero
    if (len(cadena)>1):

        # Obtenemos el primer caracter
        primero = cadena[:1]        

        # Verificamos si son iguales
        if (primero == caracter):    
            # Devuelve la Posición
            resultado = pos

        else:                
            # Obtiene el Resto de la cadena
            restoCadena = cadena[1:]

            # Llama a la función con el resto
            resultado = fnBuscarPosCaracter(restoCadena,caracter,pos+1)
                        
    
    # Retorna
    return resultado

# Probamos
print("Buscando en Hola Mundo, la a :" ,fnBuscarPosCaracter("Hola Mundo","a"))
print("Buscando en Hola Mundo, la M :" ,fnBuscarPosCaracter("Hola Mundo","M"))
print("Buscando en Hola Mundo, la H :" ,fnBuscarPosCaracter("Hola Mundo","H"))
print("Buscando en Hola Mundo, la x :" ,fnBuscarPosCaracter("Hola Mundo","x"))
print("Buscando en Hola Mundo, la z :" ,fnBuscarPosCaracter("Hola Mundo","z"))

