# ----------------------------------------
# 08 - Ejercicios de Recursividad
# Convertir de HExadecimal a Base 10 Recursivo
# ----------------------------------------

# Ejercicio 6
# Convertir un numero en base 16 a base 10

# 256      16       1
#           4       4
# 0*16e2 + 4*16e1 + 4*16e0 = 
# 0      + 64     + 4*1    =
# 68

# 256      16       1
#           8       7
# 0*16e2 + 8*16e1 + 7*16e0 = 
# 0      + 128     +7    =
# 135

# 256      16         1
#           f         f
# 0*16e2 + 15*16e1 + 15*16e0 = 
# 0      + 240     + 15    =
# 255

# 256      16         1
#   1       0         0
# 1*16e2 +  0*16e1 +  0*16e0 = 
# 256    +  0      +  0    =
# 256


# Función para obtener el digito Hexadecimal de 10 hasta 15
def fnObtenerDigitoHexadecimal(valor):
    # Resultado
    resultado = ""

    if (valor   == 10):
       resultado = "a"
    elif (valor == 11):
       resultado = "b" 
    elif (valor == 12):
       resultado = "c" 
    elif (valor == 13):
       resultado = "d" 
    elif (valor == 14):
       resultado = "e"          
    elif (valor == 15):
       resultado = "f" 

    # Devuelve el resultado
    return resultado  

# Función para verificar que una cadena tenga solo 0,1,2,3,4,5,6,7,8,9,a,b,c,d,e,f
def fnEsNumeroHexadecimal(numero):

    # Lista de Digitos válidos
    lstDigitosHexadecimales =['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']

    # Variable de resultado
    resultado = True

    # Ciclo para recorrer cada caracter
    for caracter in numero:

       # Verifica que sea un digito hexadecimal
       if lstDigitosHexadecimales.index(caracter)<0:

           # Cambiamos el resultado
           resultado = False

           # Salimos del Ciclo
           break

    # Retorna el resultado
    return resultado


# Convertir un Numero en Base 16 a base 10
def fnNumeroBase16ABase10(numeroBase16):
    """Función Recursiva para Convertir un Numero Base 8 a Base 10"""
  
    # Variable de Resultado
    resultado = 0

    # Verificamos que longitud es mayor que 0
    if (len(numeroBase16) >0):

        # Verificamos que sea binario
        if (fnEsNumeroHexadecimal(numeroBase16)):
            
            # obtengo el digito izquierdo
            digitoIzquierdo = numeroBase16[:1]

            # Verifica sus valores
            if   (digitoIzquierdo=='a'):
                digitoIzquierdo = 10
            elif (digitoIzquierdo=='b'):   
                digitoIzquierdo = 11
            elif (digitoIzquierdo=='c'):   
                digitoIzquierdo = 12
            elif (digitoIzquierdo=='d'):   
                digitoIzquierdo = 13
            elif (digitoIzquierdo=='e'):   
                digitoIzquierdo = 14
            elif (digitoIzquierdo=='f'):   
                digitoIzquierdo = 15            
            else:
                digitoIzquierdo = int(digitoIzquierdo)    
            
            # Obtiene el exponente
            exponente = len(numeroBase16)-1

            # Obtenemos el resultado
            valor =  digitoIzquierdo * 16 ** exponente 

            print("Sumando digito izquierdo:",digitoIzquierdo," :",valor)

            # resultado
            resultado = valor + fnNumeroBase16ABase10(numeroBase16[1:])

            # Retorna
            print("El Numero Hexadecimal:",numeroBase16,"a base 10 es:",resultado)
        
        else:
            # Mensaje
            print("Error. El numero no es Hexadecimal ...")        
    
        
    # Retorna    
    return resultado

# Probamos
base10  = fnNumeroBase16ABase10("44")
print()

base10  = fnNumeroBase16ABase10("87")
print()

base10  = fnNumeroBase16ABase10("ff")
print()

base10  = fnNumeroBase16ABase10("100")
print()
