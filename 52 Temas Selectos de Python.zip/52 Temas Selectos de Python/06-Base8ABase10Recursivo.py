# ----------------------------------------
# 06 - Ejercicios de Recursividad
# Convertir de Octal a Base 10 Recursivo
# ----------------------------------------


# Ejercicio 4
# Convertir un numero en base 8 a base 10

# 64      8       1
# 2       0       7
# 2*8e2 + 0*8e1 + 7*8e0 = 
# 2*64  + 0     + 7*1    =
# 128   + 0     + 7
# 135


# Función para verificar que una cadena tenga solo 0,1,2,3,4,5,6,7
def fnEsNumeroOctal(numero):

    # Variable de resultado
    resultado = True

    # Ciclo para recorrer cada caracter
    for caracter in numero:

       # Verifica que sea un 1 o 0 
       if (int(caracter)<0 or int(caracter)>7):
           # Cambiamos el resultado
           resultado = False

           # Salimos del Ciclo
           break

    # Retorna el resultado
    return resultado


# Convertir un Numero en Base 8 a base 10
def fnNumeroBase8ABase10(numeroBase8):
    """Función Recursiva para Convertir un Numero Base 8 a Base 10"""
  
    # Variable de Resultado
    resultado = 0

    # Verificamos que longitud es mayor que 0
    if (len(numeroBase8) >0):

        # Verificamos que sea binario
        if (fnEsNumeroOctal(numeroBase8)):
            
            # obtengo el digito izquierdo
            digitoIzquierdo = int(numeroBase8[:1])
            
            # Obtiene el exponente
            exponente = len(numeroBase8)-1

            # Obtenemos el resultado
            valor =  digitoIzquierdo * 8 ** exponente 

            print("Sumando digito izquierdo:",digitoIzquierdo," :",valor)

            # resultado
            resultado = valor + fnNumeroBase8ABase10(numeroBase8[1:])

            # Retorna
            print("El Numero Octal:",numeroBase8,"a base 10 es:",resultado)
            
        else:
            # Mensaje
            print("Error. El numero no es octal ...")        
    
    # Retorna    
    return resultado

# Probamos
base10  = fnNumeroBase8ABase10("207")


