# ---------------------------------------
# 15 - Ejercicios de Recursividad
# ---------------------------------------

# Exponenciación Recursivamente

# 5e0           =   1
# 5e1 = 5 * 5e0 =   5
# 5e2 = 5 * 5e1 =  25
# 5e3 = 5 * 5e2 = 125

# Exponenciar Recursivamente
def fnExponenciarRecursivamente(numero, exponente):
    """Función Recursiva para exponenciar"""
  
    # Variable de Resultado
    resultado    = 1

    # Validamos que el dividendo sea mayor que el divisor
    if (exponente > 0):

        # Obtenemos el resultado recursivamente
        resultado  = numero * fnExponenciarRecursivamente(numero,exponente-1)
            
    # Mensaje
    print(numero,"e",exponente,"=",resultado)
                
    # Retorna
    return resultado

# Probamos
fnExponenciarRecursivamente(5,0)
print()

fnExponenciarRecursivamente(5,1)
print()

fnExponenciarRecursivamente(5,2)
print()

fnExponenciarRecursivamente(5,3)
print()

fnExponenciarRecursivamente(5,4)
print()

fnExponenciarRecursivamente(5,5)
print()


