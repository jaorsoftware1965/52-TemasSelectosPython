# ----------------------------------
# 05 - Ejercicio de Recursividad
# Convertir de Base 10 a Octal
# ----------------------------------

# Ejercicio 3.
# Convertir un numero en base 10 a base 8

# 35 / 8 = 4 Residuo 3
#  4 / 8 = 0 Residuo 4
# Octal -> 43

# 135 / 8 = 16 Residuo 7
#  16 / 8 =  2 Residuo 0
#   2 / 8 =  0 Residuo 2
# Octal -> 207


# Convertir un Numero de Base 10 a Octal Usando Recursividad
def fnNumeroBase10ABase8(numeroBase10):
    """Función Recursiva para Convertir un Numero Base 10 a Base 8"""
  
    # Variable de Resultado
    resultado = ""

    # Validamos el Numero
    if (numeroBase10>=0):

        # Verificamos que es mayor que 0
        if (numeroBase10 >0):    
            # Obtiene el Residuo
            residuo = str(numeroBase10 % 8)

            # Calcula el resultado llamando a función recursiva
            resultado = fnNumeroBase10ABase8(int(numeroBase10/8)) + residuo
                        
            # Despliega el resultado
            print("El Octal de ", numeroBase10, "es:",resultado)                
    else:
        print("Error en Numero en Base 10")        

    
    # Retorna
    return resultado

# Probamos
base8 = fnNumeroBase10ABase8(35)
print()
base8 = fnNumeroBase10ABase8(135)

