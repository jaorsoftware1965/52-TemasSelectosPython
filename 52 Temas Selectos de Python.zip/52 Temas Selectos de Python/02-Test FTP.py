# -------------------------------
# 02 - Cliente FTP
# -------------------------------

# Importa la Libreria
from ftplib import FTP

# Accedemos al host
print("Accediendo al Host ...")
ftp = FTP('ftp.us.debian.org')  # connect to host, default port

# ralizamos un login
print("Login ...")
ftp.login()                     # user anonymous, passwd anonymous@

# Cambiamos al directorio 
print("Cambiando al directorio ...")
ftp.cwd('debian')               # change into "debian" directory

# Listamos el directorio
print("Listando Directorio ...")
ftp.retrlines('LIST')           # list directory contents

# Descargamos un archivo
print("Descargando archivo ...")
with open('README', 'wb') as fp:
   # Obtenemos el Archivo 
   ftp.retrbinary('RETR README', fp.write)

# Salimos   
print("Salida ...")
ftp.quit()
