# ---------------------------------------
# 14 - Ejercicios de Recursividad
# ---------------------------------------

# Tabla de Multiplicar
# 5 x 1  =  5
# 5 x 2  = 10
# ....
# 5 x 10 = 50

# Tabla Multiplicar Recursivamente
def fnTablaMultiplicarRecursivamente(tabla, multiplicador=1):
    """Función Recursiva para dividir"""
  
    # Si el Multiplicador es 1 desplegamos titulo
    if (multiplicador == 1):
        # Mensaje
        print("Tabla de Multiplicar del ",tabla)

    # Imprimimos
    print(tabla,"*",multiplicador,"=",tabla*multiplicador)    

    # Validamos que sea menor que 10
    if (multiplicador < 10):

        # LLamamos Recursivamente
        fnTablaMultiplicarRecursivamente(tabla,multiplicador+1)
        


# Probamos
fnTablaMultiplicarRecursivamente(5)

