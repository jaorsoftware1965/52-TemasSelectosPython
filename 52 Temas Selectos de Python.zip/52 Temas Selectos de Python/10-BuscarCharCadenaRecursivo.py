# ---------------------------------------
# 10 - Ejercicios de Recursividad
# ---------------------------------------


# Buscar un Caracter en una cadena


# Verifica si es palíndrome
def fnBuscarCaracter(cadena, caracter):
    """Función Recursiva para buscar un Caracter en una Cadena"""
  
    # Variable de Resultado
    resultado = False

    # Validamos el Numero
    if (len(cadena)>1):

        # Obtenemos el primer caracter
        primero = cadena[:1]        

        # Verificamos si son iguales
        if (primero == caracter):    

            # Devuelve True
            resultado = True
        else:    
            
            # Obtiene el Resto de la cadena
            restoCadena = cadena[1:]

            # Llama a la función con el resto
            resultado = fnBuscarCaracter(restoCadena,caracter)
                        
    
    # Retorna
    return resultado

# Probamos
print("Buscando en Hola Mundo, la a :" ,fnBuscarCaracter("Hola Mundo","a"))
print("Buscando en Hola Mundo, la M :" ,fnBuscarCaracter("Hola Mundo","M"))
print("Buscando en Hola Mundo, la H :" ,fnBuscarCaracter("Hola Mundo","H"))
print("Buscando en Hola Mundo, la x :" ,fnBuscarCaracter("Hola Mundo","x"))
print("Buscando en Hola Mundo, la z :" ,fnBuscarCaracter("Hola Mundo","z"))

