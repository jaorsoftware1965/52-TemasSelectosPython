# ----------------------------------------
# 04 - Ejercicios de Recursividad
# Convertir de Binario a Base 10 Recursivo
# ----------------------------------------

# 100 10  1
#   3  8  4

# Ejercicio 2
# Convertir un numero en base 2 a base 10

# 543210
# 100110

# 1*2e5 + 0*2e4 + 0*2e3 + 1*2e2 + 1*2e1 + 0*2e0 = 
# 32    + 0     + 0     + 4     + 2     + 0     =
# 38


# Función para verificar que una cadena tenga solo 1's y 0's
def fnEsNumeroBinario(numero):

    # Variable de resultado
    resultado = True

    # Ciclo para recorrer cada caracter
    for caracter in numero:

       # Verifica que sea un 1 o 0 
       if (caracter !='1' and caracter!='0'):
           # Cambiamos el resultado
           resultado = False

           # Salimos del Ciclo
           break

    # Retorna el resultado
    return resultado


# Convertir un Numero en Base 2 a base 10
def fnNumeroBase2ABase10(numeroBase2):
    """Función Recursiva para Convertir un Numero Base 2 a Base 10"""
  
    # Variable de Resultado
    resultado = 0

    # Verificamos que es 0
    if (len(numeroBase2) >0):

        # Verificamos que sea binario
        if (fnEsNumeroBinario(numeroBase2)):
            
            # obtengo el digito izquierdo
            digitoIzquierdo = int(numeroBase2[:1])
            
            # Obtiene el exponente
            exponente = len(numeroBase2)-1

            # Obtenemos el resultado
            valor =  digitoIzquierdo * 2 ** exponente 

            print("Sumando digito izquierdo:",digitoIzquierdo," :",valor)

            # resultado
            resultado = valor + fnNumeroBase2ABase10(numeroBase2[1:])

            # Retorna
            print("El Numero Binario:",numeroBase2,"a base 10 es:",resultado)
            
        else:
            # Mensaje
            print("Error. El numero no es binario ...")        
    
    # Retorna    
    return resultado

# Probamos
base10  = fnNumeroBase2ABase10("100110")


