# ---------------------------------------
# 09 - Ejercicios de Recursividad
# ---------------------------------------

# Verificar si una cadena es palíndrome
# Consideraciones 
# Si la longitud de la cadena es 1, el resultado es true
# Si la longitud de la cadena es mayor que 1, el primer y ultimo
# caracter debe ser iguales

# Verifica si es palíndrome
def fnEsPalindrome(cadena):
    """Función Recursiva para Verificar que es una cadena palíndrome"""
  
    # Variable de Resultado
    resultado = True

    # Validamos la longitud Numero
    if (len(cadena)>1):

        # Obtenemos el primer caracter y el ultimo
        primero = cadena[:1]
        ultimo  = cadena[len(cadena)-1]

        # Verificamos si son iguales
        if (primero == ultimo):    
            
            # Obtiene el Residuo
            restoCadena = cadena[1:len(cadena)-1]

            # Calcula el resultado llamando a función recursiva
            resultado = fnEsPalindrome(restoCadena)
                        
        else:
            # Mensaje
            print("Falló en:",primero,"con:",ultimo)

            # El resultado es falso
            resultado = False    
    
    # Retorna
    return resultado

# Probamos
print("13       :" ,fnEsPalindrome("13"))
print()
print("313      :", fnEsPalindrome("313"))
print()
# print("aca      :" ,fnEsPalindrome("aca"))
# print()
print("134565431:", fnEsPalindrome("134565431"))
print()
print("civic    :", fnEsPalindrome("civic"))
print()
print("civico   :", fnEsPalindrome("civico"))
print()
print("civxc    :", fnEsPalindrome("civxc"))

