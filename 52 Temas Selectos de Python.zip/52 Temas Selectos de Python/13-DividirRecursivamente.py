# ---------------------------------------
# 13 - Ejercicios de Recursividad
# ---------------------------------------


# Dividir Recursivamente

# 14 / 3 = 4 y residuo 2

# 14 - 3 = 11 (1)
# 11 - 3 =  8 (2)
#  8 - 3 =  5 (3)
#  5 - 3 =  2 (4)

# El Cociente es el numero de veces que se pudo hacer la resta: 4
# El Residuo es el resultado de la ultima resta: 2

# Dividir Recursivamente
def fnDividirRecursivamente(dividendo, divisor):
    """Función Recursiva para dividir"""
  
    # Variable de Resultado
    resultado    = []
    nvoDividendo = 0
    residuo      = 0

    # Validamos que el dividendo sea mayor que el divisor
    if (dividendo > divisor):

        # Obtenemos el nvoDividendo
        nvoDividendo = dividendo - divisor 

        # Verificamos si hay que restar de nuevo
        if (nvoDividendo >= divisor):    
            
            # Se ejecuta la recursividad
            cociente,residuo =  fnDividirRecursivamente(nvoDividendo,divisor)
            cociente = cociente + 1
            
            # Mensaje
            print(dividendo,"/",divisor,"=",cociente," Residuo:",residuo)
        else:
            # Creamos el Cociente y el divisor
            cociente = 1
            residuo  = nvoDividendo
            
    else:
        print("Error.El Dividendo debe ser Mayor que el Divisor ...")                    
    
    # Devolvemos el Cociente y el Residuo
    resultado.append(cociente)
    resultado.append(residuo)

    # Retorna
    return resultado

# Probamos
fnDividirRecursivamente(13,2)
print()
fnDividirRecursivamente(17,4)
print()
fnDividirRecursivamente(18,4)
print()
x = fnDividirRecursivamente(19,4)
print("Cociente:",x[0])
print("Residuo :",x[1])
print()

