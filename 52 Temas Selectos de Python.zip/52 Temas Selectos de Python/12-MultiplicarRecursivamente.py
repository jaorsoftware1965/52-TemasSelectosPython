# ---------------------------------------
# 12 - Ejercicios de Recursividad
# ---------------------------------------

# Multiplicar Recursivamente

# 5 * 3 = 15
# 5 + 5 + 5

# 7 * 5 = 35
# 7 + 7 + 7 + 7 + 7 = 35

# Multiplicar Recursivamente
def fnMultiplicarRecursivamente(numero, multiplicador):
    """Función Recursiva para dividir"""
  
    # Variable de Resultado
    resultado    = 0

    # Validamos que el multiplicador sea mayor 0
    if (multiplicador > 0):

        # Obtenemos el resultado recursivamente
        resultado  = numero + fnMultiplicarRecursivamente(numero, multiplicador-1)
            
        # Mensaje
        print(numero,"*",multiplicador,"=",resultado)
                
    # Retorna
    return resultado

# Probamos
fnMultiplicarRecursivamente(5,3)
print()

fnMultiplicarRecursivamente(7,5)
print()
