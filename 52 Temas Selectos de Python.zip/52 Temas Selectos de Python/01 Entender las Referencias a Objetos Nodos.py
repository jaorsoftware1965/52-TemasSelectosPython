# ----------------------------------------------------------------------
# 01 Entender el manejo de variables con tipos base, y de variables
# con objetos como nodos y sus referencias
# Manejo de Memoria Dinámica en Algoritmos y estructuras de Datos
# ----------------------------------------------------------------------


# definimos la Clase
class Nodo:

    # Constructor
	def __init__(self, dato):
		
        ## información del nodo
		self.dato = dato

		## apuntador a siguiente
		self.sgte = None

# Declaramos una variable y hacemos que otra sea igual a ella
# Usamos Char
x = 'a'
y = x

# Imprimos los datos
print(x)
print(y)

# Modificar
x='_'
print(x)
print(y)
print()


# Usamos Integer
x = 10
y = x
print(x)
print(y)

# Modificamos
x=8
print(x)
print(y)
print()

# Usamos Decimal
x = 3.1416
y = x
print(x)
print(y)

# Modificamos
x = 3.15
print(x)
print(y)
print()

# Usamos una lista
x = [14,15,10]
y = x
print(x)
print(y)

# Modificamos
x.clear()
print(x)
print(y)
print()


# Creamos un nodo
nodo1 = Nodo(1)
cabeza = nodo1
print(nodo1.dato)
print(cabeza.dato)

# Modificamos nodo1
nodo1.dato = 15
print(nodo1.dato)
print(cabeza.dato)

# Modificamos desde cabeza
cabeza.dato = 35
print(nodo1.dato)
print(cabeza.dato)

# Creamos otro nodo
nodo2 = Nodo(22)

# Hacemos que siguiente apunte a nodo2
nodo1.sgte = nodo2

# Visualmente está asi
# cabeza -> nodo1.sgte -> nodo2


# Imprimimos el valor de nodo 2 desde diversos puntos
print(nodo2.dato)
print(nodo1.sgte.dato)    # Esto hace lo mismo
print(cabeza.sgte.dato)   # que  esto

# Hago que cabeza sea un numero
cabeza.sgte.dato = 100

print(nodo2.dato)
print(nodo1.sgte.dato)    
print(cabeza.sgte.dato)   
